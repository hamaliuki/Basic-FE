//   ....1....
console.log("Задание 1");
let d = Number(7);
console.log(d);
console.log(d**2);
console.log(d**3);



// ....2....
console.log("Задание 2");
let n1 = Number(prompt('Введите первое число'));
let n2 = Number(prompt('Введите второе число'));
if(n1>n2){
    console.log(n1+n2);
}
else if(n1<n2){
    console.log(n1*n2);
}
else{
    console.log("Числа одинаковые");
}



// ....3....
console.log("Задание 3");
let n = Number(prompt('Введите любое целое число'));
if (n>0) {
    console.log(n**3);
}
else{console.log('Число не положительное');}



// ....4....
console.log("Задание 4");
let students = Number(prompt('Введите количство учеников в класе'));
let chair = Number(prompt('Введите количество стульев в кабинете'));
if (chair>=students) {
    console.log('Стульев хватает');
}
else{console.log('Стульев не хватает');}



// ....5....
console.log("Задание 5");
for (i=1; i<10; i++){
    console.log(i);
}


//....6....
console.log("Задание 6");
let ar = [3, 65, 0, 33, 15, -5, 17, 22, 4,-33, 18];
for(let i=0; i<ar.length; i++){
    if (ar[i]>=15) {
    console.log(ar[i]);
    }
}



//....7....
console.log("Задание 7");
for(let i=0; i<ar.length; i++){
    if(ar[i]<0){
        console.log(ar[i]);
    }
}



//....8....
console.log("Задание 8");
for(let i=1; i<ar.length; i++){
    if (i%3 === 0) {
        console.log(ar[i]);
    }
}



//....9....
console.log("Задание 9");
let array = [3, 65, 0, 33, 15, -5, 17, 22, 4,-33, 18];
let sum = 0;
for (let i = 0; i < array.length; i++) {
    if (array[i]<0) {
        sum = sum + array[i];
        }
    }
    console.log(sum);



//....10....
console.log("Задание 10");
let mas = [3, 65, 0, 33, 15, -5, 17, 22, 4,-33, 18];
let sumEven = 0;
let sumOdd = 0;
for (let i = 0; i < array.length; i++) {
    if (mas[i]%2 === 0) {
        sumEven = sumEven + mas[i];
        }
    else{
        sumOdd = sumOdd + mas[i];
    }
}
console.log(sumEven + sumOdd);
if (sumEven > sumOdd) {
    console.log(sumEven - sumOdd);
}
else {console.log(sumOdd - sumEven);
}